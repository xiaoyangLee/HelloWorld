<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>管理试题库</title>
	<script type="text/javascript">
		//不知道为何出了故障，暂不使用。
		function loginCheck() {
			var username = document.forms[0].username.value;
			var	password = document.forms[0].password.value;
			if (username == "" || password == "") {
				window.alert("用户名或者密码不得为空！");
			}

	</script>
</head>
<body>
<form action="./loginProceed.php" method="POST">
	用户名：<input type="text" name="username"/>
	<br>
	密&nbsp;&nbsp;&nbsp;码：<input type="password" name="password"/>
	<br>
	<input type="submit" name="login" value="登录"/>
</form>
</body>
</html>

