<?php 
	/**
	* Database操作类
	*/
	class DBhelper
	{	
		//根据id修改数据
		public function update($id=37,$ask='我又修改了一遍',$answer='哼哼哈哈')
		{
			$mysqli = new mysqli('127.0.0.1', 'root', '','OnlineEvaluation');
		if ($mysqli->connect_error) {
		die('Connect Error (' . $mysqli->connect_errno . ') '
		. $mysqli->connect_error);
		}	
			//设置utf-8编码
			$mysqli->query('SET NAMES utf8');
			$result = $mysqli->query("UPDATE t_info SET exam = ".$ask.",answer = ".$answer."
			WHERE id =".$id);
			if ($result) {
				header("location:./admin.php");
			
			}else{
				echo "修改失败";
				exit();
			}
			$result->close();
			$mysqli->close();
		}


		//根据id查询exam数据
		public function queryById($id)
		{
			$mysqli = new mysqli('127.0.0.1', 'root', '','OnlineEvaluation');
		if ($mysqli->connect_error) {
		die('Connect Error (' . $mysqli->connect_errno . ') '
		. $mysqli->connect_error);
		}	
			//设置utf-8编码
			$mysqli->query('SET NAMES utf8');
			$result = $mysqli->query("SELECT exam FROM t_info where id =".$id);
			while($row=$result->fetch_array()){
				echo $row[0];
			}
			$result->close();
			$mysqli->close();
		}
		//根据id查询answer数据
		public function queryAnswerById($id)
		{
			$mysqli = new mysqli('127.0.0.1', 'root', '','OnlineEvaluation');
		if ($mysqli->connect_error) {
		die('Connect Error (' . $mysqli->connect_errno . ') '
		. $mysqli->connect_error);
		}	
			//设置utf-8编码
			$mysqli->query('SET NAMES utf8');
			$result = $mysqli->query("SELECT answer FROM t_info where id =".$id);
			while($row=$result->fetch_array()){
				echo $row[0];
			}
			$result->close();
			$mysqli->close();
		}

		//新建一条数据
		public function insert($ask,$answer)
		{
			$mysqli = new mysqli('127.0.0.1', 'root', '','OnlineEvaluation');
		if ($mysqli->connect_error) {
		die('Connect Error (' . $mysqli->connect_errno . ') '
		. $mysqli->connect_error);
		}	
			//设置utf-8编码
			$mysqli->query('SET NAMES utf8');
			$result = $mysqli->query("insert into t_info values(null,'".$ask."','".$answer."')");
			if ($result) {
				header("location:./admin.php");
			}else{
				echo "插入失败";
				exit();
			}
			$result->close();
			$mysqli->close();
		}

		//查询所有
		function queryAll(){

		$mysqli = new mysqli('127.0.0.1', 'root', '','OnlineEvaluation');
		if ($mysqli->connect_error) {
		die('Connect Error (' . $mysqli->connect_errno . ') '
		. $mysqli->connect_error);
		}
		//设置utf-8编码
		$mysqli->query('SET NAMES utf8');
	if ($result = $mysqli->query("SELECT * FROM t_info group by id desc")) {
		//printf ("%s %s %s\n", $row[0], $row[1],$row[2]);
   		while($row=$result->fetch_array()){	
   			echo "<tr>";
   			
   			echo "<td id='id'>";
   			echo $row[0];
  			echo "</td>";
 			
 			echo "<td>";
   			echo $row[1];
   			echo "</td>";

   			echo "<td>";
   			echo $row[2];
   			echo "</td>";
   			
   			echo "<td>";
   			echo "<button><a href='edit.php?flag=0&id=".$row[0]."'>编辑</a></button>";
   			echo "</td>";

   			echo "<td>";
   			echo "<button><a href='editProceed.php?flag=2&id=".$row[0]."'>删除</a></button>";
   			echo "</td>";
			echo "</tr>";
		}	
		$result->close();
		}
	$mysqli->close();
	}
	
}
	
