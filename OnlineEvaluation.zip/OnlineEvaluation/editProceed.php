<?php 
		include 'DBhelper.php';
		$db = new DBhelper();
		//标志位为0判断为编辑一条已有信息
		if ($_GET['flag']==0) {
			$db->update($id=37,$ask='我又修改了一遍',$answer='哼哼哈哈');
		}
		
		//标志为1判断为新建一条信息
		if ($_GET['flag']==1) {
			$db->insert($_GET['ask'],$_GET['answer']);
		}	
		//标志位为2判断为删除一条信息
		if ($_GET['flag']==2) {
			echo "删除一条信息";
		}
		
 ?>