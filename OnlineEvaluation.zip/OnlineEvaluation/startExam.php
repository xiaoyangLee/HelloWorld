<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="./css/style.css">
<script type="text/javascript" src="./js/util.js"></script>
<script type="text/javascript" src="./js/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		var i = 1;
  $("#viewanswer").click(function(){
  	$(".answer").fadeIn();
  });
  $("#next").click(function(){
  		i++;
  	 	if (i>3) {
  		window.alert("没有更多的题目了!");
  		return;
  	}
  	$(".answer").hide();	
  	$(".exam"+(i-1)).hide();
  	$(".exam"+i).fadeIn();
  });

  $("#last").click(function(){
  	i--;
  	if (i<=0) {
  		window.alert("没有题目了！")
  		return;
  	}
  	$(".exam"+(i+1)).hide();
  	$(".exam"+i).fadeIn();	
  	$(".answer").fadeIn();
  });
});
</script>
</head>
<body onload="startTime()">
<div id="starttime"></div>
<div class = "exam1">
	<?php 
		echo "这是第一道题这是第一道题这是第一道题这是第一道题这是第一道题这是第一道题这是第一道题";
	 ?>
</div>
<div class = "exam2">
	<?php 
		echo "这是第二道题这是第二道题这是第二道题这是第二道题这是第二道题这是第二道题这是第二道题";
	 ?>
</div>
<div class = "exam3">
	<?php 
		echo "这是第三道题这是第三道题这是第三道题这是第三道题这是第三道题这是第三道题这是第三道题";
	 ?>
</div>
<div class="answer">
	<?php 
		echo "这是第一道题的答案";
	 ?>
</div>
<div class="button">
	<button id = "viewanswer" type="button">查看答案</button>
	<button id = "last" type="button">上一道题</button>
	<button id = "next" type="button">下一道题</button>
</div>
</body>
</html>
