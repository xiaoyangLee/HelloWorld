<!DOCTYPE html>
<html>
<head>
	<?php 
		include 'DBhelper.php';
		$db = new DBhelper();
	?>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" type="text/css" href="./css/style.css">
	<script type="text/javascript" src="./js/jquery-3.2.1.min.js"></script>
	<script type="text/javascript">
		function editclick(){
			//var arr = document.getElementById("id").innerHTML;

			window.alert("你点击了edit");
			return;
		}
		function deleteclick(var value) {
			window.alert("你点击了delete"+value);
			return;
		}
	</script>
	<title>管理员页面</title>
</head>
<body>
<div class="add"><h3><a href="edit.php?flag=1">点击这里添加试题</a></h3></div>
<table class="showtable" border="1px">
	<?php 
		$db->queryAll();
	 ?>
</table>
</body>
</html>